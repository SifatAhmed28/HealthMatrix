<?php
require_once 'config.php';

// Verify doctor authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header('Location: login.php');
    exit();
}

$doctor_id = $_SESSION['user_id'];
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 10;
$offset = ($current_page - 1) * $records_per_page;

// Get doctor details
$stmt = $pdo->prepare("SELECT full_name FROM DoctorDetails WHERE doctor_id = ?");
$stmt->execute([$doctor_id]);
$doctor = $stmt->fetch();

// Get total count of patients
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM Appointments WHERE doctor_id = ? GROUP BY patient_id");
$count_stmt->execute([$doctor_id]);
$total_patients = $count_stmt->rowCount();

// Get paginated list of patients
$patients = [];
try {
    $stmt = $pdo->prepare("
        SELECT p.patient_id, p.full_name, p.date_of_birth, p.gender, 
               MAX(a.appointment_date) as last_visit,
               COUNT(a.appointment_id) as total_visits
        FROM PatientDetails p
        JOIN Appointments a ON p.patient_id = a.patient_id
        WHERE a.doctor_id = ?
        GROUP BY p.patient_id
        ORDER BY last_visit DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$doctor_id, $records_per_page, $offset]);
    $patients = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching patients: " . $e->getMessage());
    $error = "Unable to load patient data. Please try again later.";
}

// Handle patient search
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_term = '%' . $_GET['search'] . '%';
    $stmt = $pdo->prepare("
        SELECT p.patient_id, p.full_name, p.date_of_birth, p.gender, 
               MAX(a.appointment_date) as last_visit,
               COUNT(a.appointment_id) as total_visits
        FROM PatientDetails p
        JOIN Appointments a ON p.patient_id = a.patient_id
        WHERE a.doctor_id = ? AND (p.full_name LIKE ? OR p.patient_id LIKE ?)
        GROUP BY p.patient_id
        ORDER BY last_visit DESC
    ");
    $stmt->execute([$doctor_id, $search_term, $search_term]);
    $patients = $stmt->fetchAll();
    $total_patients = count($patients);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Patients | Health Matrix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #28a745;
            --secondary-color: #007bff;
            --dark-color: #343a40;
            --light-color: #f8f9fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .patient-img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--primary-color);
        }
        
        .badge-pill {
            padding: 5px 10px;
            border-radius: 50px;
        }
        
        .table th {
            border-top: none;
        }
        
        .nav-pills .nav-link.active {
            background-color: var(--primary-color);
        }
        
        .health-metric {
            font-size: 1.2rem;
            font-weight: 500;
        }
        
        .metric-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .patient-details {
                text-align: center;
            }
            
            .patient-img {
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container py-5">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-user-md me-2"></i> My Patients</h2>
                <p class="text-muted">View and manage your patients' medical records</p>
            </div>
            <div class="col-md-4">
                <form method="GET" class="d-flex">
                    <input type="hidden" name="page" value="1">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search patients..." 
                               value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                        <button class="btn btn-outline-secondary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Patient List</h5>
                <span class="badge bg-light text-dark"><?php echo $total_patients; ?> patients</span>
            </div>
            <div class="card-body">
                <?php if (empty($patients)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-user-slash fa-3x text-muted mb-3"></i>
                        <h5>No patients found</h5>
                        <p class="text-muted">You don't have any patients yet or no matches for your search.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Patient</th>
                                    <th>Age</th>
                                    <th>Gender</th>
                                    <th>Last Visit</th>
                                    <th>Visits</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($patients as $patient): 
                                    $age = date_diff(date_create($patient['date_of_birth']), date_create('today'))->y;
                                ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="images/patients/<?php echo $patient['patient_id'] % 10 ?>.jpg" 
                                                 class="patient-img me-3" alt="Patient photo">
                                            <div>
                                                <h6 class="mb-0"><?php echo htmlspecialchars($patient['full_name']); ?></h6>
                                                <small class="text-muted">ID: <?php echo $patient['patient_id']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $age; ?> years</td>
                                    <td><?php echo htmlspecialchars($patient['gender']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($patient['last_visit'])); ?></td>
                                    <td><?php echo $patient['total_visits']; ?></td>
                                    <td>
                                        <a href="patient_records.php?id=<?php echo $patient['patient_id']; ?>" 
                                           class="btn btn-sm btn-outline-primary" 
                                           title="View medical records">
                                            <i class="fas fa-file-medical"></i>
                                        </a>
                                        <a href="appointment_book.php?patient_id=<?php echo $patient['patient_id']; ?>" 
                                           class="btn btn-sm btn-outline-success" 
                                           title="Book new appointment">
                                            <i class="fas fa-calendar-plus"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if (!isset($_GET['search']) && $total_patients > $records_per_page): ?>
                    <nav aria-label="Patient pagination">
                        <ul class="pagination justify-content-center">
                            <?php if ($current_page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $current_page - 1; ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            
                            <?php 
                            $total_pages = ceil($total_patients / $records_per_page);
                            $start_page = max(1, $current_page - 2);
                            $end_page = min($total_pages, $current_page + 2);
                            
                            for ($i = $start_page; $i <= $end_page; $i++): 
                            ?>
                            <li class="page-item <?php echo $i == $current_page ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                            <?php endfor; ?>
                            
                            <?php if ($current_page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $current_page + 1; ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php include 'footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Confirm before deleting or performing sensitive actions
        document.addEventListener('DOMContentLoaded', function() {
            // Enable tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // Search form handling
            document.querySelector('form').addEventListener('submit', function(e) {
                if (this.search.value.trim() === '') {
                    window.location.href = 'doctor_patients.php';
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>