<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header("Content-Type: application/json");
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $doctor_id = $_GET['id'];

    try {
        // Safe query: no complex joins that can break
        $stmt = $pdo->prepare("
            SELECT 
                appointment_id,
                appointment_date,
                status,
                notes,
                patient_id
            FROM Appointments
            WHERE doctor_id = ?
            ORDER BY appointment_date DESC
        ");
        $stmt->execute([$doctor_id]);
        $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($appointments) {
            echo json_encode([
                "status" => "success",
                "appointments" => $appointments
            ]);
        } else {
            echo json_encode([
                "status" => "success",
                "appointments" => [],
                "message" => "No appointments found for this doctor."
            ]);
        }

    } catch (PDOException $e) {
        echo json_encode([
            "status" => "error",
            "message" => "Database error: " . $e->getMessage()
        ]);
    }

} else {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid request. Use GET and provide doctor ID."
    ]);
}
