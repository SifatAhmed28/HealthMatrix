<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type to JSON
header("Content-Type: application/json");

// Include DB connection
require_once '../config/db.php';

// Check for POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect POST data
    $patient_id = $_POST['patient_id'] ?? null;
    $doctor_id = $_POST['doctor_id'] ?? null;
    $appointment_date = $_POST['appointment_date'] ?? null;
    $notes = $_POST['notes'] ?? '';

    // Validate required fields
    if (!$patient_id || !$doctor_id || !$appointment_date) {
        echo json_encode([
            "status" => "error",
            "message" => "Missing required fields"
        ]);
        exit;
    }

    try {
        // Insert into Appointments table
        $stmt = $pdo->prepare("
            INSERT INTO Appointments (patient_id, doctor_id, appointment_date, notes) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$patient_id, $doctor_id, $appointment_date, $notes]);

        echo json_encode([
            "status" => "success",
            "message" => "Appointment booked successfully"
        ]);
    } catch (PDOException $e) {
        echo json_encode([
            "status" => "error",
            "message" => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid request method"
    ]);
}
?>
