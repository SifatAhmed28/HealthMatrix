<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
header("Content-Type: application/json");

// Database connection
require_once '../config/db.php';

// Allow DELETE or POST for localhost testing
$method = $_SERVER['REQUEST_METHOD'];
if (!in_array($method, ['DELETE', 'POST'])) {
    echo json_encode(["status" => "error", "message" => "Invalid request method. Use DELETE or POST."]);
    exit;
}

// Read input data
if ($method === 'DELETE') {
    parse_str(file_get_contents("php://input"), $data);
} else {
    $data = $_POST;
}

// Get appointment ID
$appointment_id = $data['appointment_id'] ?? null;

if (!$appointment_id) {
    echo json_encode(["status" => "error", "message" => "Missing appointment ID."]);
    exit;
}

try {
    // Update the appointment status to Cancelled
    $stmt = $pdo->prepare("UPDATE Appointments SET status = 'Cancelled' WHERE appointment_id = ?");
    $stmt->execute([$appointment_id]);

    echo json_encode([
        "status" => "success",
        "message" => "Appointment cancelled successfully."
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Database error: " . $e->getMessage()
    ]);
}
?>
