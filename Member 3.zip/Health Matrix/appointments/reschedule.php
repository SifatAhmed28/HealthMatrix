<?php
// Show errors for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type to JSON
header("Content-Type: application/json");

// Include database connection
require_once '../config/db.php';

// Allow both PUT and POST for flexibility
$method = $_SERVER['REQUEST_METHOD'];

if (!in_array($method, ['PUT', 'POST'])) {
    echo json_encode(["status" => "error", "message" => "Invalid request method. Use PUT or POST."]);
    exit;
}

// Read input data
if ($method === 'PUT') {
    parse_str(file_get_contents("php://input"), $data);
} else {
    $data = $_POST;
}

// Get inputs
$appointment_id = $data['appointment_id'] ?? null;
$new_date = $data['new_date'] ?? null;

// Validate inputs
if (!$appointment_id || !$new_date) {
    echo json_encode(["status" => "error", "message" => "Missing appointment ID or new date."]);
    exit;
}

try {
    // Update the appointment
    $stmt = $pdo->prepare("UPDATE Appointments SET appointment_date = ? WHERE appointment_id = ?");
    $stmt->execute([$new_date, $appointment_id]);

    echo json_encode([
        "status" => "success",
        "message" => "Appointment rescheduled successfully."
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Database error: " . $e->getMessage()
    ]);
}
?>
