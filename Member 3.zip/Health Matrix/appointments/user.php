<?php
// Show all PHP errors (for debugging)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Output JSON
header("Content-Type: application/json");

// Include the database connection
require_once '../config/db.php';

// Check if it's a GET request and the 'id' is provided
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $patient_id = $_GET['id'];

    try {
        // Optional: Confirm we are receiving the patient ID correctly
        // echo json_encode(["debug" => "Patient ID received", "id" => $patient_id]); exit;

        // Fetch the patient's appointments
        $stmt = $pdo->prepare("
            SELECT 
                a.appointment_id,
                a.appointment_date,
                a.status,
                a.notes,
                d.full_name AS doctor_name,
                s.name AS specialty
            FROM Appointments a
            JOIN DoctorDetails d ON a.doctor_id = d.doctor_id
            JOIN Specialties s ON d.specialty_id = s.specialty_id
            WHERE a.patient_id = ?
            ORDER BY a.appointment_date DESC
        ");
        $stmt->execute([$patient_id]);
        $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($appointments) {
            echo json_encode([
                "status" => "success",
                "appointments" => $appointments
            ]);
        } else {
            echo json_encode([
                "status" => "success",
                "appointments" => [],
                "message" => "No appointments found for this patient."
            ]);
        }

    } catch (PDOException $e) {
        echo json_encode([
            "status" => "error",
            "message" => "Database error: " . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid request. Use GET and provide patient ID."
    ]);
}
?>
